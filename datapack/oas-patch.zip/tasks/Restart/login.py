# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey
import random
from module.base.timer import Timer
from module.exception import RequestHumanTakeover, GameTooManyClickError, GameStuckError
from module.logger import logger
from tasks.Restart.assets import RestartAssets
from tasks.GameUi.assets import GameUiAssets
from tasks.Component.GeneralBuff.assets import GeneralBuffAssets
from tasks.base_task import BaseTask
import time

# 登录期间 MPay 弹窗「关掉又重弹」的容忍上限，超过说明回车已走不出去，交 Restart 重建
DESKTOP_MPAY_CLOSE_LIMIT = 5


class LoginHandler(BaseTask, RestartAssets, GameUiAssets, GeneralBuffAssets):
    character: str

    def __init__(self, *wargs, **kwargs):
        super().__init__(*wargs, **kwargs)
        self.character = self.config.restart.login_character_config.character
        self.O_LOGIN_SPECIFIC_SERVE.keyword = self.character
        # self.specific_usr = kwargs['config'].

    def _app_handle_login(self) -> bool:
        """
        最终是在庭院界面
        :return:
        """
        logger.hr('App login')
        self.device.stuck_record_add('LOGIN_CHECK')

        confirm_timer = Timer(1.5, count=2).start()
        orientation_timer = Timer(10)
        login_success = False
        # 本次登录已处理过的 MPay 弹窗次数，用于给「关掉又重弹」封顶
        popup_handled = 0

        def handle_desktop_login_popup() -> bool:
            """登录期间处理 MPay 弹窗，返回是否刚关闭了弹窗。

            MPay 是独立顶层窗口，主窗口截图识别不到，只能按 HWND 枚举检查。
            """
            nonlocal popup_handled
            if not self.device.is_desktop or not self.device.find_desktop_login_popup():
                return False
            popup_handled += 1
            if popup_handled > DESKTOP_MPAY_CLOSE_LIMIT:
                raise GameStuckError(
                    f'Desktop MPay login popup reappeared more than {DESKTOP_MPAY_CLOSE_LIMIT} times')
            if not self.device.desktop_confirm_login_popup():
                # 弹窗可能恰好在确认函数最后一次枚举后自行关闭，重新确认避免误判卡死
                if not self.device.find_desktop_login_popup():
                    return True
                # 弹窗仍存活时不能继续识别页面，否则 MPay 会被当成未知页面
                raise GameStuckError('Desktop MPay login popup cannot be closed')
            return True

        while 1:
            # MPay 可能在启动后、重登时或登录中途反复出现，每轮都要处理
            if handle_desktop_login_popup():
                continue
            # Watch device rotation
            if not login_success and orientation_timer.reached():
                # Screen may rotate after starting an app
                self.device.get_orientation()
                orientation_timer.reset()

            self.device.screenshot()
            # 截图与窗口枚举有竞态，截图后再查一次，避免刚出现的 MPay 进入图像识别
            if handle_desktop_login_popup():
                continue
            # https://github.com/runhey/OnmyojiAutoScript/pull/1761
            if not self.device.check_screen_size_sample():
                continue
            self._burst()

            # 取消继续战斗
            if self.appear_then_click(self.I_UI_CANCEL_SAMLL, interval=0.8):
                logger.info('Cancel continue battle')
                continue
            # 确认进入庭院(优化：先检测加成图标确认在庭院页面，再检测式神录图标)
            # 标题/加载界面的光效也会命中 I_BUFF_1，还需看到庭院「探索」按钮或
            # 庭院卷轴把手才算真的进了庭院，否则会一直狂点卷轴区直到
            # GameTooManyClickError（表现为 Login failed more than 3）。
            if self.appear(self.I_BUFF_1, interval=0.2):
                # 加成图标存在，确认在庭院页面
                if self.appear(self.I_MAIN_GOTO_SHIKIGAMI_RECORDS, interval=0.2):
                    # 式神录图标存在，认为已在庭院
                    if confirm_timer.reached():
                        logger.info('Login to main confirm (buff and shikigami records button appears)')
                        break
                    login_success = True
                else:
                    # 式神录图标不存在，点击展开卷轴
                    courtyard_confirmed = (
                        self.appear(self.I_MAIN_GOTO_EXPLORATION, interval=0.2)
                        or self.appear(self.I_LOGIN_SCROOLL_CLOSE, interval=0.2)
                    )
                    if courtyard_confirmed and self.click(self.C_LOGIN_SCROLL_CLOSE_AREA, interval=2):
                        logger.info('Click scroll expand area because shikigami records not found')
                        self.screenshot()
                        continue
                    confirm_timer.reset()

            # 网络异常
            # if self.ocr_appear(self.O_LOGIN_NETWORK):
            #     logger.error('Network error')
            #     raise RequestHumanTakeover('Network error')

            # 跳过观看视频
            # if self.ocr_appear_click(self.O_LOGIN_SKIP_1, interval=1):
            #     continue
            # 下载插画
            if self.appear_then_click(self.I_LOGIN_LOAD_DOWN, interval=1):
                logger.info('Download inbetweening')
                continue
            # 不观看视频
            if self.appear_then_click(self.I_UI_CANCEL_SAMLL, interval=0.6):
                logger.info('Close video')
                continue
            # 右上角的红色的关闭
            if self.appear_then_click(self.I_LOGIN_RED_CLOSE, interval=0.6):
                logger.info('Close red close')
                continue
            # 左上角的黄色关闭
            if self.appear_then_click(self.I_LOGIN_YELLOW_CLOSE, interval=0.6):
                logger.info('Close yellow close')
                continue
            # 绑定手机号弹窗
            if self.appear_then_click(self.I_LOGIN_LOGIN_GOTO_BIND_PHONE):
                while 1:
                    self.screenshot()
                    if self.appear_then_click(self.I_UI_CANCEL_SAMLL):
                        logger.info("Close bind phone")
                        break
                continue
            # 关闭各种邀请弹窗(主要时结界卡寄养邀请)
            from tasks.Component.GeneralInvite.assets import GeneralInviteAssets as gia
            if self.appear_then_click(gia.I_I_REJECT, interval=0.8):
                logger.info("reject invites")
                continue
            # 关闭阴阳师精灵提示
            if self.appear_then_click(self.I_LOGIN_LOGIN_ONMYOJI_GENIE):
                logger.info("click onmyoji genie")
                continue
            # 「选择区域」界面：选中角色进入游戏。
            # 当前版本是角色卡片列表，不再有可点的空白区域，而且旧模板
            # 识别不到这个界面会导致一直点「进入游戏」到 GameTooManyClickError。
            if self.appear(self.I_LOGIN_SPECIFIC_SERVE, interval=0.6):
                character = (getattr(self, 'character', '') or '').strip()
                clicked = self.ocr_appear_click(
                    self.O_LOGIN_SPECIFIC_SERVE, interval=1.5)
                if not clicked and not character:
                    # 没配置角色名时点第一张卡（最近登录的服务器）
                    clicked = self.click(
                        self.C_LOGIN_ENSURE_LOGIN_CHARACTER_IN_SAME_SVR,
                        interval=2,
                    )
                if clicked:
                    logger.info('login specific user')
                    self._server_select_clicks = (
                        getattr(self, '_server_select_clicks', 0) + 1
                    )
                    if self._server_select_clicks > 6:
                        raise GameStuckError(
                            'Stuck on server select screen: '
                            'character click has no effect'
                        )
                continue
            
            # 创建角色, 误入新区直接重启
            if self.appear(self.I_CREATE_ACCOUNT):
                logger.warning('Appear create account')
                raise GameStuckError('Appear create account')

            # 点击“进入游戏”速度过快会进入区服设置，同时需在检测I_LOGIN_8之前检测，因为新服图标会让I_LOGIN_8向右偏移导致永远无法检测成功
            # 同时修复了点击位置（之前是点击I_CHARACTARS而不是左边的区域）
            if self.appear(self.I_CHARACTARS, interval=1):
                logger.info('误入区服设置')
                # https://github.com/runhey/OnmyojiAutoScript/issues/585
                self.device.click(x=106, y=535)
                
            # 点击’进入游戏‘
            if not self.appear(self.I_LOGIN_8):
                continue
            
            # 登录体验服时，点击“进入游戏”速度过快，可能会出现体验服的弹窗
            if self.appear(self.I_EARLY_SERVER):
                if self.appear_then_click(self.I_EARLY_SERVER_CANCEL):
                    logger.info('Cancel switch from early server to normal server')
                    continue
            if self.ocr_appear_click(self.O_LOGIN_ENTER_GAME_ORIGIN, interval=3) or self.ocr_appear_click(self.O_LOGIN_ENTER_GAME, interval=3):
                self.wait_until_appear(self.I_LOGIN_SPECIFIC_SERVE, True, wait_time=5)
                continue

        return login_success

    def app_handle_login(self, *, verify_configured_character: bool = False) -> bool:
        for _ in range(2):
            self.device.stuck_record_clear()
            self.device.click_record_clear()
            try:
                character = (self.character or '').strip()
                if not self.device.is_desktop and (verify_configured_character or not character):
                    import importlib
                    import os as _os
                    import sys as _sys

                    # 兼容旧 APK 内置的 ota_updater：确保 ota_overlay/oas_mobile 优先于 APK 内置包
                    _pkg = _sys.modules.get('oas_mobile')
                    _pkg_path = getattr(_pkg, '__path__', None)
                    _ov_sub = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.dirname(__file__))), 'oas_mobile')
                    if isinstance(_pkg_path, list) and _os.path.isdir(_ov_sub):
                        _ov_norm = _os.path.normpath(_ov_sub)
                        if not _pkg_path or _os.path.normpath(str(_pkg_path[0])) != _ov_norm:
                            _pkg_path[:] = [p for p in _pkg_path if _os.path.normpath(str(p)) != _ov_norm]
                            _pkg_path.insert(0, _ov_sub)
                            _sys.modules.pop('oas_mobile.login', None)
                            importlib.invalidate_caches()
                    from oas_mobile.login import ensure_logged_in

                    display = self.device._ensure_display()
                    if display < 0 or not ensure_logged_in(display, character=character):
                        message = ('Android restart could not verify the configured character' if character
                                   else 'Android restart could not confirm login')
                        raise RequestHumanTakeover(message)
                    self.device.stuck_record_clear()
                else:
                    self._app_handle_login()
                # 桌面：登录成功后标记登录态，app_is_running 才会判定为已在游戏中
                if self.device.is_desktop:
                    self.device.desktop_mark_logged_in()
                if self.config.restart.harvest_config.enable:
                    self.harvest()
                return True
            except (GameTooManyClickError, GameStuckError) as e:
                logger.warning(e)
                self.device.app_stop()
                self.device.app_start()
                continue

        logger.critical('Login failed more than 3')
        logger.critical('Onmyoji server may be under maintenance, or you may lost network connection')
        raise RequestHumanTakeover

    def harvest(self):
        """
        获得奖励
        :return: 如果没有发现任何奖励后退出
        """
        logger.hr('Harvest')
        timer_harvest = Timer(5)  # 如果连续5秒没有发现任何奖励，退出
        skip_default = False
        courtyard_affairs_done = False  # 庭院事务只执行一次
        mail_done = False  # 邮件每轮收获最多检查一次，避免空邮箱误命中反复死循环
        harvest_deadline = Timer(45).start()  # 单轮收获总上限 45 秒，绝不拖死整个 Restart
        while not harvest_deadline.reached():
            self.device.screenshot()
            # https://github.com/runhey/OnmyojiAutoScript/pull/1761
            if not self.device.check_screen_size_sample():
                continue
            self._burst()

            # 点击'获得奖励'
            if self.ui_reward_appear_click():
                timer_harvest.reset()
                continue
            # 获得奖励
            if self.appear_then_click(self.I_UI_AWARD, interval=0.2):
                timer_harvest.reset()
                continue
            # 偶尔会打开到聊天频道
            if self.appear_then_click(self.I_HARVEST_CHAT_CLOSE, interval=1):
                timer_harvest.reset()
                continue
            # 偶尔会进入其他页面
            # 左上角的黄色关闭
            if self.appear_then_click(self.I_LOGIN_YELLOW_CLOSE, interval=0.6):
                timer_harvest.reset()
                logger.info('Close yellow close')
                continue
            # 关闭宠物小屋
            if self.appear_then_click(self.I_HARVEST_BACK_PET_HOUSE, interval=0.6):
                timer_harvest.reset()
                logger.info('Close yellow close')
                continue
            # 御魂溢确认
            if self.appear_then_click(self.I_UI_CONFIRM_SAMLL, interval=2.5):
                timer_harvest.reset()
                skip_default = True
                logger.info('Soul overflow')
                continue
            # 关闭姿度出现的蒙版
            if self.appear(self.I_HARVEST_ZIDU, interval=1):
                timer_harvest.reset()
                self.I_HARVEST_ZIDU.roi_front[0] -= 200
                self.I_HARVEST_ZIDU.roi_front[1] -= 200
                if self.click(self.I_HARVEST_ZIDU, interval=2):
                    logger.info('Close zidu')
                continue

            # 庭院事务
            if self.config.restart.harvest_config.enable_courtyard_affairs and not courtyard_affairs_done:
                self.harvest_courtyard_affairs()
                timer_harvest.reset()
                courtyard_affairs_done = True
                continue
            # 勾玉
            if self.appear_then_click(self.I_HARVEST_JADE, interval=1.5):
                timer_harvest.reset()
                continue
            # 签到
            if self.appear_then_click(self.I_HARVEST_SIGN, interval=1.5):
                self.wait_until_appear(self.I_HARVEST_SIGN_2, wait_time=2)
                timer_harvest.reset()
                continue
            # 某些活动的特殊签到，有空看到就删掉
            if self.appear_then_click(self.I_HARVEST_SIGN_3, interval=0.7):
                timer_harvest.reset()
                continue
            if self.appear_then_click(self.I_HARVEST_SIGN_4, interval=1):
                timer_harvest.reset()
                continue
            if self.appear_then_click(self.I_HARVEST_SIGN_2, interval=1.5):
                self.wait_until_appear(self.I_LOGIN_RED_CLOSE, wait_time=2)
                timer_harvest.reset()
                continue
            # 999天的签到福袋
            if self.appear_then_click(self.I_HARVEST_SIGN_999, interval=1.5):
                timer_harvest.reset()
                continue
            # 判断是否勾选了收取邮件（不收取邮件可以查看每日收获）
            if not skip_default and not mail_done and self.config.restart.harvest_config.enable_mail:
                mail_done = True
                if self.harvest_mail():
                    timer_harvest.reset()
                    continue
            if self.appear_then_click(self.I_HARVEST_AP, interval=1, threshold=0.7):
                timer_harvest.reset()
                continue
            # 御魂觉醒加成
            if self.appear_then_click(self.I_HARVEST_SOUL, interval=1):
                timer_harvest.reset()
                continue
            # 寮包
            if self.appear_then_click(self.I_HARVEST_GUILD_REWARD, interval=2):
                timer_harvest.reset()
                continue
            # 自选御魂
            if not skip_default and self.appear(self.I_HARVEST_SOUL_1):
                logger.info('Select soul 2')
                self.ui_click(self.I_HARVEST_SOUL_1, stop=self.I_HARVEST_SOUL_2)
                self.ui_click(self.I_HARVEST_SOUL_2, stop=self.I_HARVEST_SOUL_3, interval=3)
                self.ui_click_until_disappear(click=self.I_HARVEST_SOUL_3)
                timer_harvest.reset()

            # 红色的关闭
            if self.appear(self.I_LOGIN_RED_CLOSE):
                self.click(self.I_LOGIN_RED_CLOSE, interval=2)
                timer_harvest.reset()
                continue

            # 五秒内没有发现任何奖励，退出
            if not timer_harvest.started():
                timer_harvest.start()
            else:
                if timer_harvest.reached():
                    logger.info('No more reward')
                    return

    def set_specific_usr(self, character: str):
        self.character = character
        self.O_LOGIN_SPECIFIC_SERVE.keyword = character

    def harvest_mail(self) -> bool:
        if not self.appear_multi_scale(self.I_HARVEST_MAIL,scale_range=(0.8, 1.1)) and \
                not self.appear(self.I_HARVEST_MAIL_COPY):
            if not self.appear(self.I_READ_ALL_MAIL):
                return False
        logger.info('Harvest mail')
        open_timer = Timer(8).start()
        opened = False
        while not open_timer.reached():
            self.screenshot()
            if self.appear(self.I_READ_ALL_MAIL):
                opened = True
                break
            if self.appear_then_click_multi_scale(self.I_HARVEST_MAIL, interval=1.5, scale_range=(0.8, 1.1)):
                continue
            if self.appear_then_click(self.I_HARVEST_MAIL_COPY, interval=1.5):
                continue
        if not opened:
            logger.warning('Harvest mail open timeout (no unread mail), skip')
            return False
        timeout_timer = Timer(6).start()
        logger.info('Exec harvest mail')
        while 1:
            self.screenshot()
            if timeout_timer.reached():
                break
            if self.appear_then_click(self.I_UI_CONFIRM, interval=0.8):
                break

            if self.appear_then_click(self.I_READ_ALL_MAIL, interval=1.5):
                continue
            if self.appear_then_click(self.I_HARVEST_MAIL_ALL, interval=1.5):
                continue
            if self.appear_then_click(self.I_MAIL_RED_POINT, interval=4):
                continue
        self.ui_click_until_disappear(self.I_LOGIN_RED_CLOSE)
        return True
    
    def harvest_courtyard_affairs(self) -> bool:
        if not self.ui_click_multi_scale(self.I_NOTE, self.I_PAGE, timeout=3, scale_range=(0.8, 1.2)):
            logger.warning('courtyard affairs timeout!')
            return False
        count_success = 0
        daily_selected = False
        clicks = {}
        reward_clicks = 0
        timeout = Timer(30).start()
        idle = Timer(8).start()

        def click_limited(rule, limit=3, interval=1):
            name = str(rule)
            if clicks.get(name, 0) >= limit:
                return False
            if not self.appear_then_click(rule, interval=interval):
                return False
            clicks[name] = clicks.get(name, 0) + 1
            idle.reset()
            return True

        while not timeout.reached():
            self.screenshot()
            if self.appear(self.I_NO_TASKS):
                logger.info('courtyard affairs completed！')
                return True
            # 每日六星御魂
            if click_limited(self.I_HARVEST_SOUL_2) \
                    or click_limited(self.I_HARVEST_SOUL_3):
                continue
            # 点击'获得奖励'
            if reward_clicks < 3 and self.ui_reward_appear_click():
                reward_clicks += 1
                idle.reset()
                continue
            # 获得奖励
            if click_limited(self.I_UI_AWARD, interval=0.2):
                continue
            # 式神满级，是否提取物经验？确定
            if click_limited(self.I_CONFIRM):
                continue

            # 日常标签在选中后仍然可见；只选择一次，随后处理完成按钮。
            if not daily_selected and click_limited(self.I_DAILY, limit=1):
                daily_selected = True
                continue
            # 领取成功： 太傻逼了收取结界奖励游戏里面居然没有加上限制
            if click_limited(self.I_SUCCESS_CLAIMED):
                continue
            if click_limited(self.I_SKIP, limit=2):# 万花牌跳过
                continue
            if click_limited(self.I_LOGIN_RED_CLOSE, limit=2):# 万花牌X
                continue
            # 一键完成
            if count_success >= 3:
                logger.warning('庭院事务已尝试三次完成，仍未确认完成，结束本轮收取')
                return False
            if click_limited(self.I_COMPLETE_TASKS, limit=3, interval=2.3):
                count_success += 1
                continue
            if idle.reached():
                logger.warning('庭院事务页面未继续推进，结束本轮收取，保留已成功的登录')
                return False
        logger.warning('庭院事务收取超时，结束本轮收取，保留已成功的登录')
        return False
