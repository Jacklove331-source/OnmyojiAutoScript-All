# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey
import time
import re

from module.logger import logger
from module.atom.image import RuleImage

from tasks.GameUi.page import page_main, page_guild
from tasks.GameUi.game_ui import GameUi
from tasks.Component.Buy.buy import Buy
from tasks.RichMan.assets import RichManAssets
from tasks.RichMan.config import GuildStore


class ButtonException(Exception):
    pass


class Guild(Buy, GameUi, RichManAssets):

    def execute_guild(self, con: GuildStore=None):

        if not con.enable:
            return
        logger.hr('Start guild', 1)
        self.goto_page(page_guild)
        while 1:
            self.screenshot()
            if self.appear(self.I_GUILD_CLOSE_RED):
                break
            if self.appear_then_click(self.I_GUILD_SHRINE, interval=0.8):
                continue
            if self.appear_then_click(self.I_GUILD_STORE, interval=1.1):
                continue
        logger.info('Enter guild store success')
        time.sleep(0.5)
        # while 1:
        #     self.screenshot()
        #     # 功勋商店 购买皮肤券 现在问题是皮肤券作为下滑判断标志,下滑过程中roi_front[1]发生了变化,
        #     # 导致后续识别本周剩余数量位置偏差,现在解决方案是创建一个相同属性的I_GUILD_SKIN_CHECK 来作为判断标志
        #     if self.appear(self.I_GUILD_SKIN_CHECK):
        #         break
        #     if self.swipe(self.S_GUILD_STORE, interval=1.5):
        #         time.sleep(2)
        #         continue
        # self.wait_until_stable(self.I_GUILD_SKIN_CHECK)
        # 开始购买
        # if con.mystery_amulet:
        #     # 蓝票
        #     self._guild_mystery_amulet()
        # if con.black_daruma_scrap:
        #     # 黑碎
        #     self._guild_black_daruma_scrap()
        # if con.skin_ticket:
        #     # 皮肤券
        #     self._guild_skin_ticket(con.skin_ticket)


        # 对应的图片, 对应的函数
        # 这里的顺序就是，在游戏中出现的顺序
        items = [
            *([(self.I_GUILD_BLUE, self._guild_mystery_amulet)] if con.mystery_amulet else []),
            *([(self.I_GUILD_SCRAP, self._guild_black_daruma_scrap)] if con.black_daruma_scrap else []),
            *([(self.I_GUILD_SKIN, self._guild_skin_ticket)] if con.skin_ticket else []),
        ]
        items_all_done = False
        swipe_no_progress = 0
        while 1:
            self.screenshot()
            bought_this_round = False
            for item in items:
                button, func = item
                if not self.appear(button):
                    continue
                self.wait_until_stable(button)
                try:
                    func()
                    # 如果这里是最后一个，就是代表前面的都购买完成了
                    if item == items[-1]:
                        items_all_done = True
                    items.remove(item)
                    bought_this_round = True
                    swipe_no_progress = 0
                except ButtonException as e:
                    logger.warning(f'Button {button.name} click failed')
                break
            if items_all_done:
                logger.info(f'All items have been purchased {items}')
                break
            # 刚购买成功: 先等待界面稳定并重新识别, 视野内还有商品就继续买, 不要急着滑动
            if bought_this_round:
                time.sleep(1)
                continue
            # 连续多次滑动都没有买到东西, 防止无限滑动触发点击保护
            swipe_no_progress += 1
            if swipe_no_progress >= 8:
                logger.warning(f'Swipe {swipe_no_progress} times without buying, stop guild store')
                break
            if self.swipe(self.S_GUILD_STORE, interval=1.5):
                time.sleep(2)
                continue


        # 回去
        while 1:
            self.screenshot()
            if self.appear(self.I_GUILD_SHRINE):
                break
            if self.appear_then_click(self.I_GUILD_CLOSE_RED, interval=1):
                continue
            if self.appear_then_click(self.I_UI_BACK_YELLOW, interval=1):
                continue

    def _guild_mystery_amulet(self):
        # 蓝票
        logger.hr('Guild mystery amulet', 2)
        self.screenshot()
        if not self.buy_check_money(self.O_GUILD_TOTAL, 240):
            return False
        number = self.check_remain(self.I_GUILD_BLUE)
        if number == 0:
            logger.warning('No mystery amulet can buy')
            return False
        self.buy_more(self.I_GUILD_BLUE, number)
        time.sleep(0.5)
        return True

    def _guild_black_daruma_scrap(self):
        # 黑碎
        logger.hr('Guild black daruma scrap', 2)
        self.screenshot()
        if not self.buy_check_money(self.O_GUILD_TOTAL, 200):
            return False
        number = self.check_remain(self.I_GUILD_SCRAP)
        if number == 0:
            logger.warning('No black daruma can buy')
            return False
        self.buy_one(self.I_GUILD_SCRAP, self.I_GUILD_CHECK_SCRAP)
        time.sleep(0.5)
        return True

    def _guild_skin_ticket(self, num: int = 0):
        # 皮肤券
        logger.hr('Guild skin ticket', 2)
        if num == 0:
            logger.warning('No buy skin ticket')
            return False
        self.screenshot()
        if not self.buy_check_money(self.O_GUILD_TOTAL, 50):
            return False
        # 检查功勋商店皮肤券 本周剩余数量
        number = self.check_remain(self.I_GUILD_SKIN)
        if number == 0:
            logger.warning('No skin ticket can buy')
            return False
        # 购买功勋商店皮肤券
        self.buy_more(self.I_GUILD_SKIN, number)
        time.sleep(0.5)
        return True

    def check_remain(self, image: RuleImage) -> int:
        if not self.appear(image):
            logger.warning(f'Image {image.name} not appear')
            return 0
        self.O_GUILD_REMAIN.roi[0] = image.roi_front[0] - 38
        self.O_GUILD_REMAIN.roi[1] = image.roi_front[1] + 83
        logger.info(f'Image roi {image.roi_front}')
        logger.info(f'Image roi {self.O_GUILD_REMAIN.roi}')
        self.screenshot()
        result = self.O_GUILD_REMAIN.ocr(self.device.image)
        logger.warning(result)
        result = result.replace('？', '2').replace('?', '2').replace(':', '；')
        if '本周剩余数量' not in result:
            raise ButtonException(f'Image {image.name} ocr result is empty: {result}')
        try:
            result = re.findall(r'本周剩余数量(\d+)', result)[0]
            result = int(result)
        except:
            result = 0
        logger.info('Remain: %s' % result)
        return int(result)


if __name__ == '__main__':
    from module.config.config import Config
    from module.device.device import Device

    c = Config('oas1')
    d = Device(c)
    t = Guild(c, d)

    # t._guild_skin_ticket(5)
    t.execute_guild(con=c.rich_man.guild_store)


