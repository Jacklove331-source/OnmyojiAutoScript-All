# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey
from datetime import timedelta, time, datetime
from time import sleep
from typing import List

import re
import cv2
from cached_property import cached_property

from module.atom.image import RuleImage, available_rules
from module.atom.ocr import RuleOcr
from module.base.timer import Timer
from module.exception import GamePageUnknownError, TaskEnd
from module.logger import logger
from tasks.Component.Costume.config import MainType
from tasks.Component.GeneralBattle.config_general_battle import GeneralBattleConfig
from tasks.GameUi.page import page_main, page_exploration, page_shikigami_records
from tasks.Secret.script_task import ScriptTask as SecretScriptTask
from tasks.WantedQuests.assets import WantedQuestsAssets
from tasks.WantedQuests.config import CooperationType, CooperationSelectMask
from tasks.WantedQuests.explore import WQExplore, ExploreWantedBoss
from tasks.WantedQuests.ui_wq_v2 import WantedQuestsUiV2


class ScriptTask(WantedQuestsUiV2, WQExplore, SecretScriptTask, WantedQuestsAssets):
    want_strategy_excluding: list[list] = []  # 不需要执行的
    # 追踪界面(显示"前往"按钮的界面,左上角位置,神秘任务不好使)显示以下名称时,任务不再执行
    unwanted_boss_name_list: list = []

    def run(self):
        con = self.config.model.wanted_quests
        unwanted_boss_names = con.wanted_quests_config.unwanted_boss_names
        if unwanted_boss_names is not None and unwanted_boss_names != '':
            import re
            self.unwanted_boss_name_list = re.split(r"[，,]", unwanted_boss_names)

        # 自动换御魂
        if con.switch_soul_config.enable:
            self.goto_page(page_shikigami_records)
            self.run_switch_soul(con.switch_soul_config.switch_group_team)
        if con.switch_soul_config.enable_switch_by_name:
            self.goto_page(page_shikigami_records)
            self.run_switch_soul_by_name(con.switch_soul_config.group_name, con.switch_soul_config.team_name)

        # 新 UI（2026-10）：面板 = 标题「悬赏封印」+ 三张卡；旧的 I_TRACE_* 模板已失效，
        # 因此先探测新面板，命中就直接走 v2 流程，不再走旧的追踪/列表逻辑。
        self.goto_page(page_main)
        if self.wq2_open_panel():
            logger.info('[WQ] new UI detected, run v2 flow')
            self.run_v2()
            return

        preSuc = False
        if (self.get_config()).cooperation_only:
            preSuc = self.pre_work_cooperation_only()
        else:
            preSuc = self.pre_work()
        if not preSuc:
            # 无法完成预处理 很有可能你已经完成了悬赏任务
            logger.warning('Cannot pre-work')
            logger.warning('You may have completed the reward task')
            self.next_run()
            raise TaskEnd('WantedQuests')

        self.screenshot()
        number_challenge = self.O_WQ_NUMBER.ocr(self.device.image)
        error_count = 0
        while 1:
            self.screenshot()
            if not self.is_wq_remained():
                logger.info("no more wq remained")
                break
            if self.appear(self.I_WQ_BOX):
                logger.info("get reward")
                self.ui_get_reward(self.I_WQ_BOX)
                continue
            if self.appear(self.I_TREASURE_BOX_CLICK):
                logger.info("get treasure")
                self.ui_get_reward(self.I_TREASURE_BOX_CLICK)
                continue
            if error_count > 3:
                logger.warning('failed too many times, exit')
                break
            if self.current_count >= 30:
                logger.error(f'current count {self.current_count} >= 20, exit')
                raise Exception('current count >= 20, exit')
            cu, re, total, area = self.find_wq(self.device.image)
            logger.info(f"find_wq result: current {cu} remain {re} total {total} area {area}")
            if re == -2:
                logger.info("only completed wanted quests remained")
                break
            if re == -1:
                error_count += 1
                # 没找到任务 尝试上滑
                self.swipe(self.S_WQ_LIST_UP, interval=1)
                sleep(1)
                continue
            # 找到任务,执行
            error_count = 0
            self.O_WQ_TEXT_ALL.area = area
            self.execute_mission(self.O_WQ_TEXT_ALL, total - cu, number_challenge)
            sleep(1.5)

        self.next_run()
        raise TaskEnd('WantedQuests')

    def run_v2(self, max_rounds: int = 12):
        """读取新版悬赏卡的推荐地点，执行已接入的战斗路线。"""
        wq_config = self.get_config()
        actions = {'秘闻': self.secret, '式神': self.challenge}
        allowed = {self.wq2_map_type(kind) for kind in wq_config.battle_priority.split('>')}
        skipped_cards = {}  # 值为 True 表示按目标黑名单跳过。
        finished = False
        handled = 0
        invited_once = False
        for _ in range(max_rounds):
            # 打完一场会回到探索页；wq2_ensure_panel 会处理「探索页 → 回主界面 → 开面板」
            if not self.wq2_ensure_panel():
                logger.warning('[WQ] cannot open wanted-quest panel, stop')
                break
            # 协作邀请：面板左侧有「邀请好友」就邀请（配置 NoInvite 时跳过）
            if not invited_once and self._cooperation_invites_enabled():
                invited_once = True
                invited = self.wq2_invite_friends(
                    count=5, preferred=getattr(wq_config, 'invite_friend_name', '') or '')
                if invited:
                    logger.info(f'[WQ] cooperation invite sent: {invited}')
                    self.wq2_open_panel()
                    if getattr(wq_config, 'cooperation_only', False):
                        logger.info('[WQ] cooperation_only enabled, stop after inviting')
                        self.next_run()
                        raise TaskEnd('WantedQuests')

            # 读卡前确保在面板：邀请/详情流程可能把界面留在详情页，
            # 直接读卡会把详情页当成面板 → 误判「没有未完成任务」。
            if not self.wq2_panel_visible():
                logger.info('[WQ] not on panel before card scan, closing detail')
                self.wq2_close_detail()
                self.wq2_open_panel()
            if not self.wq2_panel_visible():
                logger.warning('[WQ] panel not visible, stop this round')
                break

            remaining = [(card, (card['index'], card['text']))
                         for card in self.wq2_unfinished_cards()]
            pending = next(((card, key) for card, key in remaining
                            if key not in skipped_cards), None)
            if pending is None:
                finished = all(skipped_cards[key] for _, key in remaining)
                break
            card, card_key = pending
            logger.info(f"[WQ] card {card['index']}: {card['text']} "
                        f"{card['current']}/{card['total']}")
            if not self.wq2_open_card(card):
                logger.warning('[WQ] cannot open card detail, skip to next')
                skipped_cards[card_key] = False
                self.wq2_close_detail()
                continue
            rows = self.wq2_rows()
            logger.info('[WQ] rows: ' + '; '.join(
                f"{r['type']}/{r['destination']}({r['number']})"
                f"@{r['goto']}" for r in rows))
            candidates = []
            for row in rows:
                kind = self.wq2_map_type(row['type'])
                if kind not in actions or kind not in allowed:
                    continue
                if not row['goto'] or row['number'] <= 0:
                    continue
                candidates.append((kind, row))
            if not candidates:
                logger.warning('[WQ] no supported route with a recognized count, skip to next card')
                skipped_cards[card_key] = False
                self.wq2_close_detail()
                continue
            # 秘闻优先（数量多、收益稳定），其余按原顺序
            candidates.sort(key=lambda item: 0 if item[0] == '秘闻' else 1)
            kind, row = candidates[0]
            target_name = self.O_WQ_MONSTER_TYPE.detect_text(self.device.image)
            if target_name in self.unwanted_boss_name_list:
                logger.warning(f'[WQ] unwanted boss {target_name}, skip')
                skipped_cards[card_key] = True
                self.wq2_close_detail()
                continue
            num_want = card['total'] - (card['current'] or 0)
            do_number = 1 if row['number'] >= num_want else (
                num_want // row['number'] + (1 if num_want % row['number'] else 0))
            logger.info(f'[WQ] go {kind} {row["destination"]} x{do_number}')
            actions[kind](row['goto'], do_number)
            handled += 1
        if finished or wq_config.cooperation_only:
            logger.info(f'[WQ] v2 finished, handled={handled}')
            self.next_run()
        else:
            logger.warning(f'[WQ] v2 stopped with unfinished quests, handled={handled}')
            self.set_next_run(task='WantedQuests', success=False, finish=True, server=False)
        raise TaskEnd('WantedQuests')

    def next_run(self):
        before_end: time = self.get_config().before_end
        if before_end == time(hour=0, minute=0, second=0):
            self.set_next_run(task='WantedQuests', success=True, finish=True)
            return
        time_delta = timedelta(hours=-before_end.hour, minutes=-before_end.minute, seconds=-before_end.second)
        now_datetime = datetime.now()
        now_time = now_datetime.time()
        if time(hour=5) <= now_time < time(hour=18):
            # 如果是在5点到18点之间，那就设定下一次运行的时间为第二天的5点 + before_end
            next_run_datetime = datetime.combine(now_datetime.date() + timedelta(days=1), time(hour=5))
            next_run_datetime = next_run_datetime + time_delta
        elif time(hour=18) <= now_time < time(hour=23, minute=59, second=59):
            # 如果是在18点到23点59分59秒之间，那就设定下一次运行的时间为第二天的18点 + before_end
            next_run_datetime = datetime.combine(now_datetime.date() + timedelta(days=1), time(hour=18))
            next_run_datetime = next_run_datetime + time_delta
        else:
            # 如果是在0点到5点之间，那就设定下一次运行的时间为今天的18点 + before_end
            next_run_datetime = datetime.combine(now_datetime.date(), time(hour=18))
            next_run_datetime = next_run_datetime + time_delta
        self.set_next_run(task='WantedQuests', target=next_run_datetime)

    def pre_work(self):
        """
        前置工作，
        :return:
        """
        self.goto_page(page_main)
        done_timer = Timer(5)
        while 1:
            self.screenshot()
            if self.appear(self.I_TRACE_DISABLE):
                break
            if self.appear_then_click(self.I_WQ_SEAL, interval=1):
                continue
            if self.appear_then_click_multi_scale(self.I_WQ_DONE,scale_range=(0.8, 1.2) ,interval=1):
                continue
            if self.appear_then_click(self.I_TRACE_ENABLE, interval=1):
                continue
            if self.special_main and self.click(self.C_SPECIAL_MAIN, interval=3):
                logger.info('Click special main left to find wanted quests')
                continue
            if self.appear(self.I_UI_BACK_RED):
                if not done_timer.started():
                    done_timer.start()
            if done_timer.started() and done_timer.reached():
                self.ui_click_until_disappear(self.I_UI_BACK_RED)
                return False
        # 已追踪所有任务
        logger.info('All wanted quests are traced')

        # 存在协作任务则邀请
        self.screenshot()
        if self._cooperation_invites_enabled() and (
            self.appear(self.I_WQ_INVITE_1) or self.appear(self.I_WQ_INVITE_2) or self.appear(self.I_WQ_INVITE_3)
        ):
            if self.need_invite_vip():
                self.all_cooperation_invite()
            else:
                self.invite_five()
        self.ui_click_until_disappear(self.I_UI_BACK_RED)
        self.goto_page(page_exploration)
        return True

    def pre_work_cooperation_only(self):
        if not self._cooperation_invites_enabled():
            logger.info('Cooperation invitations are disabled')
            return False
        #
        if self.get_current_page() != page_main:
            self.goto_page(page_main)
        # 打开悬赏封印 界面
        done_timer = Timer(5)
        while 1:
            self.screenshot()
            if self.appear(self.I_TRACE_ENABLE) or self.appear(self.I_TRACE_DISABLE):
                break
            if self.appear_then_click(self.I_WQ_SEAL, interval=1):
                continue
            if self.appear_then_click_multi_scale(self.I_WQ_DONE,scale_range=(0.8, 1.2), interval=1):
                continue
            if self.special_main and self.click(self.C_SPECIAL_MAIN, interval=3):
                logger.info('Click special main left to find wanted quests')
                continue
            if self.appear(self.I_UI_BACK_RED):
                if not done_timer.started():
                    done_timer.start()
            if done_timer.started() and done_timer.reached():
                self.ui_click_until_disappear(self.I_UI_BACK_RED)
                return False
        #
        if not (self.appear(self.I_WQ_INVITE_1) or self.appear(self.I_WQ_INVITE_2) or self.appear(self.I_WQ_INVITE_3)):
            logger.info("there is no cooperation quest")
            return False

        # if self.appear(self.I_WQ_INVITE_1):
        #     self.trace_one(self.I_WQ_INVITE_1)
        # if self.appear(self.I_WQ_INVITE_2):
        #     self.trace_one(self.I_WQ_INVITE_2)
        # if self.appear(self.I_WQ_INVITE_3):
        #     self.trace_one(self.I_WQ_INVITE_3)

        # 追踪任务 并邀请
        self.all_cooperation_invite()

        self.ui_click_until_disappear(self.I_UI_BACK_RED)
        self.goto_page(page_exploration)
        return True

    def trace_one(self, btn: RuleImage):
        """
            参数必须为邀请按钮(I_WQ_INVITE_n ),特定场景,就不做通用的函数了,怪麻烦的,若还有什么奇葩需求,再扩展吧
        @param btn: 邀请按钮,
        @type btn:
        """
        self.screenshot()
        if not self.appear(btn):
            return
        while 1:
            self.screenshot()
            # 追踪成功  或  是现世任务 不需要追踪
            if self.appear(self.I_WQ_TRACE_ONE_ENABLE) or self.appear(self.I_WQ_TRACE_ONE_REALWORLD):
                break
            if self.appear(self.I_WQ_TRACE_ONE_DISABLE):
                self.click(self.I_WQ_TRACE_ONE_DISABLE, interval=1.5)
                continue
            # 根据邀请按钮位置生成 对应的点击位置 打开追踪界面
            # NOTE magic Number

            self.device.click(btn.roi_front[0], btn.roi_front[1] - 40, control_name=str(btn) + ' y-40')
            # 防止点击后界面来不及刷新
            sleep(1.5)
        # 关闭单个任务的追踪界面
        self.ui_click_until_smt_disappear(self.C_WQ_TRACE_ONE_CLOSE, stop=self.I_WQ_TRACE_ONE_CHECK_OPENED,
                                          interval=1.5)

    def execute_mission(self, ocr, num_want: int, num_challenge: int):
        """

        :param ocr: 要点击的 文字
        :param num_want: 一共要打败的怪物数量
        :param num_challenge: 现在有的挑战卷数量
        :return:
        """
        OCR_WQ_TYPE = [self.O_WQ_TYPE_1, self.O_WQ_TYPE_2, self.O_WQ_TYPE_3, self.O_WQ_TYPE_4]
        OCR_WQ_INFO = [self.O_WQ_INFO_1, self.O_WQ_INFO_2, self.O_WQ_INFO_3, self.O_WQ_INFO_4]
        GOTO_BUTTON = [self.I_GOTO_1, self.I_GOTO_2, self.I_GOTO_3, self.I_GOTO_4]
        name_funcs: dict = {
            '式神': self.challenge,
            '探索': self.explore,
            '秘闻': self.secret
        }

        def extract_info(index: int) -> tuple or None:
            """
            提取每一个地点的信息
            :param index: 从零开始
            :return:
            (type, destination, number, goto_button, func)
            (类型, 地点层级，可以打败的数量，前往按钮, func)
            类型： 挑战0, 秘闻1， 探索2
            """
            # 获取用户设置的值
            user_limit = self.config.model.wanted_quests.wanted_quests_config.layer_limit.value            
            # 定义完整的层数后缀顺序
            all_layers = ["壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖", "拾", "番外"]
            # 根据用户选择进行截取，生成 layer_limit 集合
            if user_limit == "无限制":
                layer_limit = set()
            else:
                start_idx = all_layers.index(user_limit) if user_limit in all_layers else 6
                # 截取该层及之后的所有层
                layer_limit = set(all_layers[start_idx:])

            # ,荒川之怒·壹，4，前往按钮，function
            result = [-1, '', -1, GOTO_BUTTON[index], self.challenge, '']
            type_wq = OCR_WQ_TYPE[index].ocr(self.device.image)
            # 移动端 OCR 常将“探索”识别为繁体/形近字“採索”
            if type_wq in ('採索', '探素'):
                type_wq = '探索'
            info_wq_1 = OCR_WQ_INFO[index].ocr(self.device.image)
            info_wq_1 = info_wq_1.replace('：', ':').replace('（', '(').replace('）', ')')
            # 兼容移动端 OCR 常见的繁体“數量”及误识“教量/数:”
            match = re.match(r"^(.*?)[（(]?[数數教]量?[：:]\s*(\d+)[)）]?", info_wq_1)
            if not match:
                return None
            wq_destination = match.group(1)
            wq_number = int(match.group(2))
            # 跳过高层秘闻
            if wq_destination[-1] in layer_limit:
                logger.warning('This secret layer is too high')
                return None
            result[1] = wq_destination
            result[2] = wq_number
            order_list = self.config.model.wanted_quests.wanted_quests_config.battle_priority
            order_list = order_list.replace(' ', '').replace('\n', '')
            order_list: list = re.split(r'>', order_list)
            # OCR识别"式神"但用户配置用"挑战"，做映射
            type_wq_for_order = '挑战' if type_wq == '式神' else type_wq
            result[0] = order_list.index(type_wq_for_order) if type_wq_for_order in order_list else -1
            result[4] = name_funcs.get(type_wq, lambda: logger.warning('No task can be challenged'))
            result[5] = type_wq
            logger.info(f'[Wanted Quests] type: {type_wq} destination: {wq_destination} number: {wq_number} ')
            return tuple(result) if result[0] != -1 else None

        logger.hr('Start wanted quests')
        while 1:
            self.screenshot()
            if self.appear(self.I_TRACE_TRUE):
                break
            if self.click(ocr, interval=1):
                continue
        if not self.appear(self.I_GOTO_1):
            # 如果没有出现 '前往'按钮， 那就是这个可能是神秘任务但是没有解锁
            logger.warning('This is a secret mission but not unlock')
            self.ui_click(self.I_TRACE_TRUE, self.I_TRACE_FALSE)
            return False
        # 跳过不想打的
        monster_name = self.O_WQ_MONSTER_TYPE.detect_text(self.device.image)
        if monster_name in self.unwanted_boss_name_list:
            #
            logger.warning(f'unwanted {monster_name}')
            self.ui_click(self.I_TRACE_TRUE, self.I_TRACE_FALSE)
            return False

        info_wq_list = []
        for i in range(4):
            info_wq = extract_info(i)
            if info_wq:
                info_wq_list.append(info_wq)
        info_wq_list = [item for item in info_wq_list if item not in self.want_strategy_excluding]
        if not info_wq_list:
            logger.warning('No wanted quests can be challenged')
            self.ui_click(self.I_TRACE_TRUE, self.I_TRACE_FALSE)
            return False
        # sort
        info_wq_list.sort(key=lambda x: x[0])
        filtered = list(filter(lambda x: (x[5] == '秘闻' or x[5] == '式神') and x[2] >= 3, info_wq_list))
        if not filtered and len(filtered) != 0:
            info_wq_list = filtered
        best_type, destination, once_number, goto_button, func, _ = info_wq_list[0]
        do_number = 1 if once_number >= num_want else num_want // once_number + (1 if num_want % once_number > 0 else 0)
        try:
            func(goto_button, do_number)
        except ExploreWantedBoss:
            logger.warning('The extreme case. The quest only needs to challenge one final boss, so skip it')
            self.want_strategy_excluding.append(info_wq_list[0])

    def _click_goto_any(self, goto, interval: float = 1.5) -> bool:
        """点「前往」。goto 可以是 RuleImage，也可以是 (x, y) 坐标（新 UI 用 OCR 定位）。"""
        if isinstance(goto, (tuple, list)) and len(goto) == 2:
            self.device.click(int(goto[0]), int(goto[1]), control_check=False)
            sleep(interval)
            return True
        return self.click(goto, interval=interval)

    def challenge(self, goto_btn, num):
        self._click_goto_any(goto_btn)
        self.wait_until_appear(self.I_WQC_FIRE, wait_time=6)
        self.ui_click(self.I_WQC_UNLOCK, self.I_WQC_LOCK)
        self.ui_click_until_disappear(self.I_WQC_FIRE)
        # 锁定阵容进入战斗
        wq_config = GeneralBattleConfig(lock_team_enable=True)
        self.run_general_battle(config=wq_config)
        self.wait_until_appear(self.I_WQC_FIRE, wait_time=4)
        # 关闭 挑战界面
        while 1:
            self.screenshot()
            if self.appear(self.I_CHECK_EXPLORATION):
                break
            if self.appear_then_click(self.I_UI_BACK_YELLOW, interval=1.5):
                continue

    def secret(self, goto, num=1):
        self._click_goto_any(goto)
        self.wait_until_appear(self.I_WQSE_FIRE, wait_time=6)
        for i in range(num):
            self.wait_until_appear(self.I_WQSE_FIRE)
            # self.ui_click_until_disappear(self.I_WQSE_FIRE)
            # 又臭又长的对话针的是服了这个网易
            click_count = 0
            while 1:
                self.screenshot()
                if not self.appear(self.I_UI_BACK_RED, threshold=0.7):
                    break
                if self.appear_then_click(self.I_WQSE_FIRE, interval=1):
                    continue
                if self.appear(self.I_UI_BACK_RED, threshold=0.7) and not self.appear(self.I_WQSE_FIRE):
                    self.click(self.C_SECRET_CHAT, interval=0.8)
                    click_count += 1
                    if click_count >= 6:
                        logger.warning('Secret mission chat too long, force to close')
                        click_count = 0
                        self.device.click_record_clear()
                    continue
            self.run_general_battle(self.battle_config)
            if not self.device.is_desktop:
                self._wait_for_mobile_secret_return(expect_challenge=i + 1 < num)
        while 1:
            self.screenshot()
            if self.appear(self.I_CHECK_SECRET_ZONES) or (
                    not self.device.is_desktop and self.appear(self.I_CHECK_EXPLORATION)):
                break
            if self.appear_then_click(self.I_UI_BACK_RED, interval=1):
                continue
            if self.appear_then_click(self.I_UI_BACK_BLUE, interval=1.5):
                continue
        self.goto_page(page_exploration)
        self.wait_until_stable(self.I_CHECK_EXPLORATION)
        logger.info('Secret mission finished')

    @staticmethod
    def _mobile_secret_dialogue_visible(image) -> bool:
        # Story captions use a red speaker ribbon and pale subtitles below it.
        ribbon = cv2.cvtColor(image[540:566], cv2.COLOR_RGB2HSV)
        hue, saturation, value = cv2.split(ribbon)
        red = ((hue <= 14) | (hue >= 170)) & (saturation >= 140) & (value >= 70)
        if max(red[:, 328:443].mean(), red[:, 835:950].mean()) < 0.27:
            return False

        subtitle = cv2.cvtColor(image[606:670, 324:925], cv2.COLOR_RGB2HSV)
        _, saturation, value = cv2.split(subtitle)
        return bool(((saturation <= 135) & (value >= 165)).mean() >= 0.009)

    def _wait_for_mobile_secret_return(self, *, expect_challenge: bool) -> None:
        timeout = Timer(30).start()
        last_subtitle = None
        while not timeout.reached():
            self.screenshot()
            if self.appear(self.I_WQSE_FIRE):
                return
            if not expect_challenge and (self.appear(self.I_CHECK_SECRET_ZONES)
                                         or self.appear(self.I_CHECK_EXPLORATION)):
                return
            if self.appear_then_click(self.I_REWARD, interval=1):
                continue
            if not self._mobile_secret_dialogue_visible(self.device.image):
                continue
            subtitle = self.device.image[606:670, 324:925]
            if last_subtitle is not None and cv2.absdiff(subtitle, last_subtitle).mean() > 2:
                self.device.click_record_remove_rule(self.C_SECRET_CHAT)
            if self.click(self.C_SECRET_CHAT, interval=0.8):
                last_subtitle = subtitle.copy()

        raise GamePageUnknownError('Secret battle did not return to the expected page')

    # 悬赏邀请表单里朋友头像的点击位。这 5 张模板图从未提交（invite/invite_wq_friend_*.png 缺失），
    # 用它点击会抛 FileNotFoundError；缺图时只跳过邀请分支，不影响单人悬赏路径。
    INVITE_FRIEND_RULES = ('I_WQ_FRIEND_1', 'I_WQ_FRIEND_2', 'I_WQ_FRIEND_3', 'I_WQ_FRIEND_4', 'I_WQ_FRIEND_5')

    def invite_friend_rules_available(self) -> bool:
        missing = [name for name in self.INVITE_FRIEND_RULES if not getattr(self, name).available]
        if missing:
            logger.warning(f'悬赏邀请缺少模板，跳过邀请分支: {missing}')
            return False
        return True

    def invite_random(self, add_button: RuleImage):
        if not self.invite_friend_rules_available():
            return False
        self.screenshot()
        if not self.appear(add_button):
            return False
        self.ui_click(add_button, self.I_WQ_INVITE_ENSURE, interval=2.5)
        logger.info('enter invite form')
        sleep(1)
        self.click(self.I_WQ_FRIEND_1)
        sleep(0.4)
        self.click(self.I_WQ_FRIEND_2)
        sleep(0.4)
        self.click(self.I_WQ_FRIEND_3)
        sleep(0.4)
        self.click(self.I_WQ_FRIEND_4)
        sleep(0.4)
        self.click(self.I_WQ_FRIEND_5)
        sleep(0.2)
        self.screenshot()
        if not self.appear(self.I_WQ_INVITE_SELECTED):
            logger.warning('No friend selected')
            return False
        self.ui_click_until_disappear(self.I_INVITE_ENSURE)
        sleep(0.5)

    def invite_five(self):
        """
        邀请好友，默认点五个
        :return:
        """

        logger.hr('Invite friends')
        self.invite_random(self.I_WQ_INVITE_1)
        self.invite_random(self.I_WQ_INVITE_2)
        self.invite_random(self.I_WQ_INVITE_3)

    def all_cooperation_invite(self, name_all: str = None):
        """
            所有的协作任务依次邀请
            如果配置了只完成协作任务 还会将该任务设置为追踪
        @return:

        """
        self.screenshot()
        if not self.appear(self.I_WQ_INVITE_1):
            return False

        ret = self.get_cooperation_info()
        if len(ret) == 0:
            logger.info("no Cooperation found")
            return False
        typeMask = 15
        typeMask = CooperationSelectMask[(self.get_config()).cooperation_type.value]
        for item in ret:
            # 该任务是需要邀请的任务类型
            if not (item['type'] & typeMask):
                # BUG 存在多个协作任务时,邀请完第一个协作任务对方接受后,未邀请的任务位置无法确定(缺少信息)
                # 例如 按顺序存在 abc 3个协作任务,邀请完a,好友接受后,这三个任务在界面上的顺序变化,abc 还是bca
                # 如果顺序不变 则应该没有问题
                logger.info("cooperationType %s But needed Type %s ,Skipped", item['type'], typeMask)
                break
            '''
               尝试5次 如果邀请失败 等待20s 重新尝试
               阴阳师BUG: 好友明明在线 但邀请界面找不到该好友(好友未接受任何协作任务的情况下)
           '''
            index = 0
            item['inviteResult'] = False
            if name_all is None:
                name = self.get_invite_vip_name(item['type'])
            else:
                name = name_all
            logger.warning("find cooperationType %s ,start invite %s", item['type'], name)
            while index < 5:
                if self.cooperation_invite(item['inviteBtn'], name):
                    item['inviteResult'] = True
                    index = 5
                    continue
                logger.info("%s not found,Wait 20s,%d invitations left", name, 5 - index - 1)
                index += 1
                sleep(20) if index < 5 else sleep(0)
                # NOTE 等待过程如果出现协作邀请 将会卡住 为了防止卡住
                self.screenshot()
            # 邀请追踪一起吧,只有邀请成功才追踪
            if item['inviteResult']:
                self.invite_success_callback(item['type'], name)
                if (self.get_config()).cooperation_only:
                    logger.info("start trace_one")
                    self.trace_one(item['inviteBtn'])
        return ret

    def cooperation_invite(self, btn: RuleImage, name: str):
        """
            单个协作任务邀请
        @param btn:
        @param name:
        @return:
        """
        self.ui_click(btn, stop=self.I_WQ_INVITE_ENSURE, interval=2.5)

        # 选人
        self.O_WQ_INVITE_COLUMN_1.keyword = name
        self.O_WQ_INVITE_COLUMN_2.keyword = name

        find = False
        for i in range(2):
            self.wait_until_appear(self.I_WQ_INVITE_FRIEND_LIST_APPEAR, wait_time=4)
            self.screenshot()
            in_col_1 = self.ocr_appear_click(self.O_WQ_INVITE_COLUMN_1)
            in_col_2 = self.ocr_appear_click(self.O_WQ_INVITE_COLUMN_2)
            find = in_col_2 or in_col_1
            if find:
                self.wait_until_appear(self.I_WQ_INVITE_SELECTED, wait_time=2)
                self.screenshot()
                if self.appear(self.I_WQ_INVITE_SELECTED):
                    logger.info("friend found and selected")
                    break
                # TODO OCR识别到文字 但是没有选中 尝试重新选择  (选择好友时,弹出协作邀请导致选择好友失败)
            # 检测跨服好友按钮是否高亮
            while 1:
                self.screenshot()
                if not self.appear_highlight(self.I_WQ_INVITE_DIFF_SVR_HIGHLIGHT):
                    self.click(self.I_WQ_INVITE_DIFF_SVR)
                    continue
                break
            # 等待好友列表加载
            self.wait_until_appear(self.I_WQ_INVITE_DIFF_SVR_HIGHLIGHT, wait_time=4)
        # 没有找到需要邀请的人,点击取消 返回悬赏封印界面
        if not find:
            self.screenshot()
            self.ui_click_until_disappear(self.I_WQ_INVITE_CANCEL, interval=1.5)
            return False
        #
        self.ui_click_until_disappear(self.I_WQ_INVITE_ENSURE, interval=1)
        return True

    def get_cooperation_info(self) -> List:
        """
            获取协作任务详情
        @return: 协作任务类型与邀请按钮
        """
        self.screenshot()
        retList = []
        i = 0
        for index in range(3):
            btn = self.__getattribute__("I_WQ_INVITE_" + str(index + 1))
            if not self.appear(btn):
                break
            if self.appear(self.__getattribute__("I_WQ_COOPERATION_TYPE_JADE_" + str(index + 1))):
                retList.append({'type': CooperationType.Jade, 'inviteBtn': btn})
                continue
            if self.appear(self.__getattribute__("I_WQ_COOPERATION_TYPE_DOG_FOOD_" + str(index + 1))):
                retList.append({'type': CooperationType.Food, 'inviteBtn': btn})
                continue
            if self.appear(self.__getattribute__("I_WQ_COOPERATION_TYPE_CAT_FOOD_" + str(index + 1))):
                retList.append({'type': CooperationType.Food, 'inviteBtn': btn})
                continue
            if self.appear(self.__getattribute__("I_WQ_COOPERATION_TYPE_SUSHI_" + str(index + 1))):
                retList.append({'type': CooperationType.Sushi, 'inviteBtn': btn})
                continue
            # NOTE 因为食物协作里面也有金币奖励 ,所以判断金币协作放在最后面
            if self.appear(self.__getattribute__("I_WQ_COOPERATION_TYPE_GOLD_" + str(index + 1))):
                retList.append({'type': CooperationType.Gold, 'inviteBtn': btn})
                continue
        logger.info(f"get cooperation size {len(retList)}")
        return retList

    # 使用平均亮度检测是否一致
    def appear_highlight(self, rule_image: RuleImage):
        def compute_region_brightness(img, top_left, width, height):
            """
            计算目标区域的平均亮度 (灰度图的平均值)
            :param img: 目标图像
            :param top_left: 匹配区域的左上角坐标
            :param width: 模板宽度
            :param height: 模板高度
            :return: 区域亮度均值
            """
            # 裁剪出匹配区域
            region = img[top_left[1]:top_left[1] + height, top_left[0]:top_left[0] + width]
            # 转为灰度图
            gray_region = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            # 计算灰度均值
            return gray_region.mean()

        src = rule_image.corp(self.device.image)
        template = rule_image.image
        result = cv2.matchTemplate(src, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(result)

        brightness_src = compute_region_brightness(src, max_loc, template.shape[1], template.shape[0])
        brightness_template = compute_region_brightness(template, (0, 0), template.shape[1], template.shape[0])

        if max_val > rule_image.threshold and (brightness_src >= brightness_template * rule_image.threshold) and (
                brightness_src <= brightness_template * (2 - rule_image.threshold)):
            rule_image.roi_front[0] = max_loc[0] + rule_image.roi_back[0]
            rule_image.roi_front[1] = max_loc[1] + rule_image.roi_back[1]
            return True
        return False

    @cached_property
    def special_main(self) -> bool:
        # 特殊的庭院需要点一下，左边然后才能找到图标
        main_type = self.config.global_game.costume_config.costume_main_type
        if main_type == MainType.COSTUME_MAIN_3:
            return True
        return False

    def get_config(self):
        return self.config.wanted_quests.wanted_quests_config

    def _cooperation_invites_enabled(self) -> bool:
        setting = getattr(self.get_config(), 'cooperation_type', None)
        return getattr(setting, 'value', setting) not in (None, 'NoInvite', 0, '0')

    def need_invite_vip(self):
        return bool(self.get_config().invite_friend_name)

    def get_invite_vip_name(self, ctype: CooperationType):
        return self.get_config().invite_friend_name

    def invite_success_callback(self, ctype: CooperationType, name):
        """
           邀请成功回调
        @param ctype:
        @type ctype:
        @param name:
        @type name:
        """

        return True

    def process_ocr(self, txt):
        def detect_spliter(txt):
            index = txt.find('/')
            if index != -1:
                return index
            # 由于斜杠'/'经常被误识别为'7',且悬赏封印悬赏怪物总数没有与‘7’相关的数字
            reg = re.compile(r'^(\d+)([7/])(\d+)$')
            match = reg.match(txt)
            if match:
                return match.start(2)
            return -1

        index = detect_spliter(txt)
        if index < 0:
            return 0, 0, 0
        return int(txt[:index]), 1, int(txt[index + 1:])

    def txt_ocr_appear(self, ocr_item: RuleOcr, reg, img):
        res = ocr_item.ocr(img)
        regex = re.compile(reg)
        ismatch = regex.match(res)
        return ismatch is not None

    def find_wq(self, img):
        def calc_xywh(box):
            rec_x, rec_y, rec_w, rec_h = box[0, 0], box[0, 1], box[1, 0] - box[0, 0], box[2, 1] - box[0, 1]
            x = rec_x + self.O_WQ_TEXT_ALL.roi[0]
            y = rec_y + self.O_WQ_TEXT_ALL.roi[1]
            w = rec_w
            h = rec_h
            return [x, y, w, h]

        res_list = self.O_WQ_TEXT_ALL.detect_and_ocr(img)
        import re
        reg_time = re.compile(r'^([01]?[0-9]|2[0-3]):([0-5]?[0-9]):?([0-5]?[0-9])?$')
        reg_fengyin = re.compile(r'.*[封|野]印.*')
        # 由于斜杠'/'经常被误识别为'7',且悬赏封印悬赏怪物总数没有与‘7’相关的数字
        reg_progress = re.compile(r'^(\d+)([7/])(\d+)$')
        # 没有检测到斜杠，符合格式：前N位与后N位相同,表示已完成
        reg_XX = re.compile(r'^(\d+)\1$')
        # 过滤掉协或者未知悬赏等其他无用字符
        reg_other = re.compile(r'[?？协边]')
        completed_only = False
        for index, res in enumerate(res_list):
            if reg_fengyin.match(res.ocr_text):
                continue
            if reg_time.match(res.ocr_text):
                continue
            if reg_other.search(res.ocr_text):
                continue
            if (match := reg_progress.match(res.ocr_text)):
                spliter_index = match.start(2)
                xywh = calc_xywh(res.box)
                self.O_WQ_TEXT_ALL.area = xywh
                cu, re, total = int(res.ocr_text[:spliter_index]), 1, int(res.ocr_text[spliter_index + 1:])
                logger.info(f'Matched: {res.ocr_text}')
                # 识别结果规范性检查
                if total > 14:
                    logger.warning("Total number of wanted quests is greater than 14")
                    total = total % 10
                if cu > total:
                    logger.warning('Current number of wanted quests is greater than total number')
                    cu = cu // 10
                if cu == total:
                    # 该任务已完成，一般是悬赏任务，邀请人没有做导致的
                    completed_only = True
                    continue
                return cu, re, total, xywh
            # 例如：1414 66 1212
            if reg_XX.match(res.ocr_text):
                continue
            # 什么都没匹配上，判断上一个识别结果如果为悬赏封印，那么认为该识别结果错误，尝试执行一次
            last_index = (index - 1) if index > 0 else 0
            if reg_fengyin.match(res_list[last_index].ocr_text):
                return 0, 1, 3, calc_xywh(res_list[last_index].box)

        if completed_only:
            return -2, -2, -2, [0, 0, 0, 0]
        return -1, -1, -1, [0, 0, 0, 0]

    def is_wq_remained(self):
        # 检测是否还存在任务
        return self.appear(self.O_WQ_WANTED)



if __name__ == '__main__':
    from module.config.config import Config
    from module.device.device import Device
    import re

    c = Config('oas1')
    d = Device(c)
    t = ScriptTask(c, d)
    # import cv2
    #
    # img = cv2.imread(r'E:\2.png')
    # img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    #
    # res = t.find_wq(img)

    t.run()
