from pydantic import BaseModel, Field

from tasks.Component.config_scheduler import Scheduler
from tasks.Component.config_base import ConfigBase

class GuildActivityMonitorCombatTime(BaseModel):
    # 设置检测时间
    detection_interval: int = Field(default=30, description="通知检测间隔（秒）\n通过adb/ocr检测收到的活动推送，自动拉起对应任务")
    monitor_duration: int = Field(default=15, description="监控持续时间（分）\n请确保已开启游戏通知权限，游戏设置权限中对应活动推送")
    recheck_interval: int = Field(default=5, description="拉起对应活动后，间隔多久再次开启检测（分）\n若监控时间内未检测到活动，则按调度器设置下次运行时间")
    run_days: str = Field(default="1,2,3,4,5,6,7", description="运行日期，1-7 对应周一到周日；例如 5,6,7")
    use_ocr: bool = Field(default=False, description="启用OCR检测模式\n勾选: 通过OCR识别屏幕通知区域文字\n不勾选: 通过adb读取系统通知(默认)\n启用此项建议检测间隔改为1-5s左右")

class GuildActivity(BaseModel):
    # 道馆
    Dokan: bool = Field(default=True)
    # 狭间
    AbyssShadows: bool = Field(default=True)
    # 宴会
    GuildBanquet: bool = Field(default=True)
    # 退治
    DemonRetreat: bool = Field(default=True)

    # 保持前端翻译，自动转换格式
    def __getattr__(self, name):
        camel = ''.join(w.capitalize() for w in name.split('_'))
        return getattr(self, camel) if hasattr(self, camel) else super().__getattr__(name)

    def __setattr__(self, name, value):
        camel = ''.join(w.capitalize() for w in name.split('_'))
        super().__setattr__(camel if hasattr(self, camel) else name, value)


class GuildActivityMonitor(ConfigBase):
    scheduler: Scheduler = Field(default_factory=Scheduler)
    guild_activity_monitor_combat_time: GuildActivityMonitorCombatTime = Field(default_factory=GuildActivityMonitorCombatTime)
    guild_activity: GuildActivity = Field(default_factory=GuildActivity)