# This Python file uses the following encoding: utf-8
# @author runhey
# github https://github.com/runhey

from module.atom.image import RuleImage
from module.atom.gif import RuleGif
from module.logger import logger
from module.server.i18n import I18n

from tasks.Component.Costume.config import (
    MainType, CostumeConfig, RealmType,
    ThemeType, ShikigamiType, SignType,
    BattleType, BattleSceneType, CarpBannerType
)
from tasks.Component.Costume.assets import CostumeAssets
from tasks.Component.CostumeBattle.assets import CostumeBattleAssets
from tasks.Component.CostumeShikigami.assets import CostumeShikigamiAssets
from tasks.Component.CostumeCarpBanner.assets import CostumeCarpBannerAssets
from tasks.Component.CostumeBattleScene.assets import CostumeBattleSceneAssets

# 庭院皮肤
# 主界面皮肤（使用字典推导式动态生成）
main_costume_model = {
    getattr(MainType, f"COSTUME_MAIN_{i}"): {
        'I_CHECK_MAIN': f'I_CHECK_MAIN_{i}',
        'I_MAIN_GOTO_EXPLORATION': f'I_MAIN_GOTO_EXPLORATION_{i}',
        'I_MAIN_GOTO_SUMMON': f'I_MAIN_GOTO_SUMMON_{i}',
        'I_MAIN_GOTO_TOWN': f'I_MAIN_GOTO_TOWN_{i}',
        'I_PET_HOUSE': f'I_PET_HOUSE_{i}'
    } for i in range(1, 17)
}
# 玉岚狐庭（issue #1824）
main_costume_model[getattr(MainType, "COSTUME_MAIN_17")] = {
    'I_CHECK_MAIN': ['I_CHECK_MAIN_17_A', 'I_CHECK_MAIN_17_B', 'I_CHECK_MAIN_17_C'],
    'I_MAIN_GOTO_EXPLORATION': ['I_MAIN_GOTO_EXPLORATION_17_A', 'I_MAIN_GOTO_EXPLORATION_17_B', 'I_MAIN_GOTO_EXPLORATION_17_C'],
    'I_MAIN_GOTO_SUMMON': ['I_MAIN_GOTO_SUMMON_17_A', 'I_MAIN_GOTO_SUMMON_17_B', 'I_MAIN_GOTO_SUMMON_17_C'],
    'I_MAIN_GOTO_TOWN': ['I_MAIN_GOTO_TOWN_17_A', 'I_MAIN_GOTO_TOWN_17_B', 'I_MAIN_GOTO_TOWN_17_C'],
    'I_PET_HOUSE': ['I_PET_HOUSE_17_A', 'I_PET_HOUSE_17_B', 'I_PET_HOUSE_17_C'],
}
main_costume_model[getattr(MainType, "COSTUME_MAIN_13")] = {
    'I_CHECK_MAIN': ['I_CHECK_MAIN_13',],
    'I_MAIN_GOTO_EXPLORATION': ['I_MAIN_GOTO_EXPLORATION_13', ],
    'I_MAIN_GOTO_SUMMON': ['I_MAIN_GOTO_SUMMON_13',],
    'I_MAIN_GOTO_TOWN': ['I_MAIN_GOTO_TOWN_13',],
    'I_PET_HOUSE': ['I_PET_HOUSE_13',],
}



# 结界皮肤（阴阳寮 → 结界）：只覆盖结界界面的 4 个入口模板
realm_costume_model = {}
for _realm_idx in range(1, 7):
    _realm_member = getattr(RealmType, f'COSTUME_REALM_{_realm_idx}', None)
    if _realm_member is None:
        continue
    realm_costume_model[_realm_member] = {
        'I_SHI_GROWN': f'I_SHI_GROWN_{_realm_idx}',
        'I_SHI_CARD': f'I_SHI_CARD_{_realm_idx}',
        'I_SHI_DEFENSE': f'I_SHI_DEFENSE_{_realm_idx}',
        'I_REALM_SHIN': f'I_REALM_SHIN_{_realm_idx}',
    }


# 鲤鱼旗皮肤
carpbanner_costume_model = {
    getattr(CarpBannerType, f"COSTUME_CARPBANNER_{i}"): {
        'I_SHI_CARD': f'I_SHI_CARD_{i}',
        'I_SHI_DEFENSE': f'I_SHI_DEFENSE_{i}',
        'I_SHI_GROWN': f'I_SHI_GROWN_{i}',
    } for i in range(1, 4)
}


# 战斗主题
battle_theme_model = {
    getattr(BattleType, f"COSTUME_BATTLE_{i}"): {
        'I_LOCAL': f'I_LOCAL_{i}',
        'I_EXIT': f'I_EXIT_{i}',
        'I_FRIENDS': f'I_FRIENDS_{i}',
        'I_BATTLE_INFO': f'I_BATTLE_INFO_{i}',
        # 以下资源并非所有主题都需要修改，未采集的资源将被跳过
        'I_WIN': f'I_WIN_{i}', # 已知：8，12，13，14
        'I_DE_WIN': f'I_DE_WIN_{i}', # 已知：8，12，13，14
        'I_FALSE': f'I_FALSE_{i}' # 已知：8，12，13，14
    } for i in range(1, 16)
}

# 战斗场景皮肤。图片资源待补充，先保留空映射。
battle_scene_model = {
    BattleSceneType.COSTUME_BATTLE_SCENE_1: {
        'I_REWARD': 'I_REWARD_1',
    },
}

# 幕间主题
shikigami_costume_model = {
    getattr(ShikigamiType, f"COSTUME_SHIKIGAMI_{i}"): {
        # GameUi 进出式神录
        'I_CHECK_RECORDS': f'I_CHECK_RECORDS_{i}',
        'I_RECORD_SOUL_BACK': f'I_RECORD_SOUL_BACK_{i}',
        # SwitchSoul 相关
        'I_SOUL_PRESET': f'I_SOUL_PRESET_{i}',
        'I_SOU_CHECK_IN': f'I_SOU_CHECK_IN_{i}',
        'I_SOU_TEAM_PRESENT': f'I_SOU_TEAM_PRESENT_{i}',
        'I_SOU_CLICK_PRESENT': f'I_SOU_CLICK_PRESENT_{i}',
        # SwitchSoul 分组相关 (1-7组)
        **{f'I_SOU_CHECK_GROUP_{g}': f'I_SOU_CHECK_GROUP_{g}_{i}' for g in range(1, 8)},
        # SwitchSoul 队伍相关 (1-4队)
        **{f'I_SOU_SWITCH_{t}': f'I_SOU_SWITCH_{t}_{i}' for t in range(1, 5)},
        # SoulsTidy 相关
        'I_ST_SOULS': f'I_ST_SOULS_{i}',
        'I_ST_REPLACE': f'I_ST_REPLACE_{i}',
    }
    for i in range(1, 13)  # 目前支持 COSTUME_SHIKIGAMI_1 到 COSTUME_SHIKIGAMI_12
}

class CostumeBase:
    def check_costume(self, config: CostumeConfig=None):
        if config is None:
            config: CostumeConfig = self.config.model.global_game.costume_config
        current_task = self.get_task_name()
        logger.info(f'Current task: {current_task}')
        self.check_costume_main(config.costume_main_type)
        self.check_costume_realm(config.costume_realm_type)
        self.check_costume_carpbanner(config.costume_carpbanner_type)
        self.check_costume_battle(config.costume_battle_type)
        self.check_costume_battle_scene(config.costume_battle_scene_type)
        self.check_costume_shikigami(config.costume_shikigami_type)

    def replace_img(self,
                    asset_before: str,
                    asset_after: RuleImage,
                    rp_roi_back: bool = True):
        if not hasattr(self, asset_before):
            return
        # setattr(self, asset_before, asset_after)
        asset_before_object: RuleImage = getattr(self, asset_before)
        asset_before_object.roi_front = asset_after.roi_front
        if rp_roi_back:
            asset_before_object.roi_back = asset_after.roi_back
        asset_before_object.threshold = asset_after.threshold
        asset_before_object.file = asset_after.file

    def check_costume_main(self, main_type: MainType):
        if main_type == MainType.COSTUME_MAIN:
            return
        logger.info(f'Switch main costume to {main_type} ({I18n.trans_zh_cn(main_type)})')
        costume_assets = CostumeAssets()
        for key, value in main_costume_model[main_type].items():
            if isinstance(value, list):
                if not hasattr(self, key):
                    continue
                rules: list[RuleImage] = [getattr(costume_assets, item) for item in value]
                RuleGif.attach_to(getattr(self, key), rules)
            else:
                assert_value: RuleImage = getattr(costume_assets, value)
                self.replace_img(key, assert_value)

    def check_costume_realm(self, realm_type: RealmType):
        if realm_type == RealmType.COSTUME_REALM_DEFAULT:
            return
        logger.info(f'Switch realm costume to {realm_type} ({I18n.trans_zh_cn(realm_type)})')
        realm_assets = CostumeAssets()
        for key, value in realm_costume_model.get(realm_type, {}).items():
            if not hasattr(realm_assets, value):
                logger.warning(f'Realm costume asset {value} not found, skip')
                continue
            self.replace_img(key, getattr(realm_assets, value))

    def check_costume_carpbanner(self, carpbanner_type: CarpBannerType):
        if carpbanner_type == CarpBannerType.COSTUME_CARPBANNER_DEFAULT:
            return
        logger.info(f'Switch carp banner theme {carpbanner_type} (override realm assets) ({I18n.trans_zh_cn(carpbanner_type)})')
        carpbanner_assets = CostumeCarpBannerAssets()
        model = carpbanner_costume_model.get(carpbanner_type, {})
        for key, value in model.items():
            if not hasattr(carpbanner_assets, value):
                logger.warning(f'Carp banner asset {value} not found, skip')
                continue
            assert_value: RuleImage = getattr(carpbanner_assets, value)
            # 执行替换（覆盖结界皮肤的同名key）
            self.replace_img(key, assert_value)

    def check_costume_battle(self, battle_type: BattleType):
        if battle_type == BattleType.COSTUME_BATTLE_DEFAULT:
            return
        logger.info(f'Switch battle theme {battle_type} ({I18n.trans_zh_cn(battle_type)})')
        costume_battle_assets = CostumeBattleAssets()
        for key, value in battle_theme_model[battle_type].items():
            if not hasattr(costume_battle_assets, value):
                # 尚未采集完成的资产，跳过
                continue
            assert_value: RuleImage = getattr(costume_battle_assets, value)
            # 绿标的坐标点范围不变
            if key == 'I_LOCAL':
                self.replace_img(key, assert_value, rp_roi_back=False)
            else:
                self.replace_img(key, assert_value)

    def check_costume_battle_scene(self, scene_type: BattleSceneType):
        if scene_type == BattleSceneType.COSTUME_BATTLE_SCENE_DEFAULT:
            return
        logger.info(f'Switch battle scene skin {scene_type} ({I18n.trans_zh_cn(scene_type)})')
        current_task = self.get_task_name()
        allowed_tasks = {
            'Orochi',
        }
        if current_task not in allowed_tasks:
            return

        costume_assets = CostumeBattleSceneAssets()
        for key, value in battle_scene_model.get(scene_type, {}).items():
            if not hasattr(costume_assets, value):
                # 尚未采集完成的资产，跳过
                continue
            assert_value: RuleImage = getattr(costume_assets, value)
            self.replace_img(key, assert_value)

    def check_costume_shikigami(self, shikigami_type: ShikigamiType):
        if shikigami_type == ShikigamiType.COSTUME_SHIKIGAMI_DEFAULT:
            return
        logger.info(f'Switch shikigami theme {shikigami_type} ({I18n.trans_zh_cn(shikigami_type)})')
        shikigami_assets = CostumeShikigamiAssets()
        model = shikigami_costume_model.get(shikigami_type, {})
        for key, value in model.items():
            if not hasattr(shikigami_assets, value):
                # 尚未采集完成的资产，跳过
                continue
            assert_value: RuleImage = getattr(shikigami_assets, value)
            # 一般不需要固定 back ROI，如确有需要可在此为特例设置 rp_roi_back=False
            self.replace_img(key, assert_value)


if __name__ == '__main__':
    c = CostumeBase()
    c.check_costume_main(MainType.COSTUME_MAIN_13)
